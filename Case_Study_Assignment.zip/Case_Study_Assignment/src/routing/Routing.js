import React from 'react';
import{BrowserRouter,Route} from 'react-router-dom'
function Routing(props) {
    return (
        <BrowserRouter>
            
        </BrowserRouter>
    );
}

export default Routing;